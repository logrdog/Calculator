/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camperinterface;

/**
 *
 * @author logan
 */
public class Camper {
    private String ID;
    private String firstName;
    private String lastName;
    private String nickname;
    private double campStoreBudget;
    private double campStoreSpent;
    
    public Camper(String _ID)
    {
        ID=_ID;
    }
    
    public void setFirstName(String name){
        firstName = name;
    }
    
    public void setLastName(String lname){
        lastName = lname;
    }
    
    public void setNickname(String Nname){
        nickname = Nname;
    }
    
    public void setStoreBudget(double budget){
        campStoreBudget = budget;
    }
    
    public void setStoreSpentAmount(double spent){
        campStoreSpent = spent;
    }
    
    public String getID(){
        return ID;
    }
    public String getFirstName(){
        return firstName;
    }
    
    public String getLastName(){
        return lastName;
    }
    
    public String getNickname(){
        return nickname;
    }
    
    public double getbudget(){
        return campStoreBudget;
    }
    
    public double getSpent(){
        return campStoreSpent;
    }
}

