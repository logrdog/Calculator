/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camperinterface;

import java.sql.*;  
/**
 *
 * @author logan
 */
public class Factory {
    public Camper getCAMPER(String ID){
        Camper camper;
        String DBstatus;
        String user = "grichards12";
        String pass = "Logs011596";
        String _ID = "", fname="", lname="", nname="";
        double campbudget=0.0, spent=0.0;
        try
        {
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@worf.radford.edu:1521:itec3",user,pass);
		Statement stmt = con.createStatement();
		String query = "SELECT ID, firstName, lastName, nickName, CampStoreBudget ,CampStoreSpent "
                + "FROM Campers "
                + "WHERE ID = '" +ID+ "'";

		ResultSet rset = stmt.executeQuery(query);
		while(rset.next())
		{
                    _ID=rset.getString("ID"); 
                    System.out.println(rset.getString("ID"));
                    fname=rset.getString("firstName");
                    System.out.println(rset.getString("firstName"));
                    lname=rset.getString("lastName"); 
                    nname=rset.getString("nickName"); 
                    campbudget=rset.getDouble("CampStoreBudget"); 
                    spent=rset.getDouble("CampStoreSpent");
                    DBstatus = "Found";
		}
			con.close();
		}
		catch(SQLException e)
		{
			DBstatus = "Error";
			System.out.println(e);
		}
                camper = new Camper(_ID);
                camper.setFirstName(fname);
                camper.setLastName(lname);
                camper.setNickname(nname);
                camper.setStoreBudget(campbudget);
                camper.setStoreSpentAmount(spent);
                
            return camper;
    }
    
    public void saveCamper(Camper camperToSave){
       Camper camper=camperToSave;
        try {
            TM(camper);
        } catch (SQLException ex) {
            System.out.println("error going into transaction");
        }
    }
    
    public void TM(Camper camper)
    throws SQLException { 
        DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());

        String user, pass, query;
        user = "grichards12";
        pass = "Logs011596";
        query = "UPDATE Campers " +
                "SET firstName = "+"'"+camper.getFirstName()+"'"+",lastName = "+"'"+camper.getLastName()+"'"+", nickname = "+"'"+camper.getNickname()+"'"+", CampStoreBudget = "+"'"+camper.getbudget()+"'"+", CampStoreSpent = "+"'"+camper.getSpent()+"'"+
                " WHERE ID= '" +camper.getID()+ "'";
    
        System.out.println(query);
    try 
    {
        Connection conn = DriverManager.getConnection
               ("jdbc:oracle:thin:@Worf.radford.edu:1521:itec3",user,pass);
        Statement stmt = conn.createStatement (); 
     
        ResultSet rset = stmt.executeQuery(query);

        System.out.println("here");
        while (rset.next ()) 
        { 
            String _ID=rset.getString("ID"); 
                    System.out.println(rset.getString("ID"));
                   String fname=rset.getString("firstName");
                    System.out.println(rset.getString("firstName"));
        } 
        conn.close();
     }
     catch (SQLException e)
     {
        System.out.println ("Could not load the db"+e); 
     }
    }
}


