/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camperinterface;

import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author logan
 */
public class CamperInterface {
   private Factory thisfactory = new Factory();
   private Camper thisCamper;
   private String strCAMPID;
   private JFrame mainFrame;
   private JLabel headerLabel;
   private JLabel statusLabel;
   private JPanel controlPanel;
   private JLabel msglabel;
   private JTextField IDfld;

   public CamperInterface(){
       prepareFrame();
       showSignOnPanel();
   }

   private void prepareFrame(){
      mainFrame = new JFrame("Camper Editor.");
      mainFrame.setSize(1000,200);
      mainFrame.setLayout(new GridLayout(3, 1));
      
      mainFrame.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
            System.exit(0);
         }        
      });    
      headerLabel = new JLabel("", JLabel.CENTER);        
      statusLabel = new JLabel("",JLabel.CENTER);    
      statusLabel.setSize(350,100);
      
      controlPanel = new JPanel();
      controlPanel.setLayout(new GridLayout());

      mainFrame.add(headerLabel);
      mainFrame.add(controlPanel);
      mainFrame.add(statusLabel);
      mainFrame.setVisible(true);  
   }
     
   private void showSignOnPanel(){
      headerLabel.setText("Camper Editor"); 
      
      JLabel  IDlabel= new JLabel("Camper ID: ", JLabel.RIGHT);
      final JTextField IDfld = new JTextField();
      JLabel  fnamelabel= new JLabel("Camper First Name: ", JLabel.RIGHT);
      final JTextField fnamefld = new JTextField();
      JLabel  lnamelabel= new JLabel("Camper Last Name: ", JLabel.RIGHT);
      final JTextField lnamefld = new JTextField();   
      JLabel  Nnamelabel= new JLabel("Camper Nickname: ", JLabel.RIGHT);
      final JTextField Nnamefld = new JTextField(); 
      JLabel  campbudgetlabel= new JLabel("Camper Budget: ", JLabel.RIGHT);
      final JTextField campbudgetfld = new JTextField();
      JLabel  spentlabel= new JLabel("Camper Spent Amount: ", JLabel.RIGHT);
      final JTextField spentfld = new JTextField();  

      JButton submitButton = new JButton("Submit");
      submitButton.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(java.awt.event.ActionEvent e) {
            boolean flag;
            String data;
            
            if (IDfld.getText().isEmpty())
            {
                flag = false;
            }else{
                flag = true;
            }
            
            if(!flag){
                data="did not succeed";
            }else{
                Camper camp=thisfactory.getCAMPER(IDfld.getText());
                data="success: (ID-"+camp.getID()+") (first name-"+camp.getFirstName()+") (last name-"+camp.getLastName()+") (nickname-"+camp.getNickname()+
                        ") (camp budget-"+camp.getbudget()+") (amount spent-"+camp.getSpent()+")";
            }
            statusLabel.setText(data);      
          }
      }); 
      
      JButton saveButton = new JButton("Save");
      saveButton.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(java.awt.event.ActionEvent e) {
            boolean flag;
            String data, ID, fname, lname, Nname;
            double campStoreBudget, spent;
            
            if(IDfld.getText().isEmpty()||fnamefld.getText().isEmpty()||lnamefld.getText().isEmpty()||Nnamefld.getText().isEmpty()
                ||campbudgetfld.getText().isEmpty()||spentfld.getText().isEmpty())
            {
                flag = false;
            }else{
                flag = true;
            }
            
            if(!flag){
                data="did not succeed, all fields must be filled with user data";
            }else{
                ID=IDfld.getText();
                fname=fnamefld.getText();
                lname=lnamefld.getText();
                Nname=Nnamefld.getText();
                campStoreBudget=Double.parseDouble(campbudgetfld.getText());
                spent=Double.parseDouble(spentfld.getText());
                data="success: "+IDfld.getText()+", "+fnamefld.getText()+", "+lnamefld.getText()+", "+Nnamefld.getText()+", $"+campbudgetfld.getText()+", $"+spentfld.getText();
                thisCamper = new Camper(ID);
                thisCamper.setFirstName(fname);
                thisCamper.setLastName(lname);
                thisCamper.setNickname(Nname);
                thisCamper.setStoreBudget(campStoreBudget);
                thisCamper.setStoreSpentAmount(spent);
                thisfactory.saveCamper(thisCamper);
            }
            statusLabel.setText(data);      
          }
      }); 
      controlPanel.add(IDlabel);
      controlPanel.add(IDfld);
      controlPanel.add(fnamelabel);
      controlPanel.add(fnamefld);
      controlPanel.add(lnamelabel);
      controlPanel.add(lnamefld);
      controlPanel.add(Nnamelabel);
      controlPanel.add(Nnamefld);
      controlPanel.add(campbudgetlabel);
      controlPanel.add(campbudgetfld);
      controlPanel.add(spentlabel);
      controlPanel.add(spentfld);
      controlPanel.add(submitButton);
      controlPanel.add(saveButton);
      mainFrame.setVisible(true);  
   }
   
}
